#include "LedMatrix.h"
//#include <fstream>
#include "Arduino.h"

LedMatrix::LedMatrix(){
    row = new byte[8];
    col = new byte[8];
    figure = new bool*[8];
    for (int i=0; i<8; ++i) figure[i] = new bool[8];
    this->clear();
}

LedMatrix::~LedMatrix(){
	delete row;
	delete col;
	delete figure;
}

void LedMatrix::setOnOffChars(char on, char off){
	this->on = on;
	this->off = off;
}

void LedMatrix::clear(){
	for (int i=0; i<8; ++i) setRowByte(i, B00000000);
}

void LedMatrix::togglePixel(byte r, byte c, bool state){
	figure[r][7-c] = state;
}

void LedMatrix::setRowString(byte rownum, String buffer){
	for (byte i=0; i<buffer.length(); ++i){
		if 		(buffer[i]==this->on)  figure[rownum][7-i] = 1;
		else if (buffer[i]==this->off) figure[rownum][7-i] = 0;
		else {
			Serial.println("Invalid character at "+String(rownum)+".row, "+String(i)+". column (index starts from 0)!!!");
			figure[rownum][7-i] = 0;
		}
	}
}

void LedMatrix::setRowByte(byte rownum, byte buffer){
	for (int i=0; i<8; ++i)
		figure[rownum][i] = ((1 << i) & buffer) > 0;
}

void LedMatrix::setColumnString(byte colnum, String buffer){
	colnum = 7-colnum;
	for (byte i=0; i<buffer.length(); ++i){
		if 		(buffer[i]==this->on)  figure[i][colnum] = 1;
		else if (buffer[i]==this->off) figure[i][colnum] = 0;
		else {
			Serial.println("Invalid character at "+String(i)+".row, "+String(colnum)+". column (index starts from 0)!!!");
			figure[i][colnum] = 0;
		}
	}
}

void LedMatrix::setColumnByte(byte colnum, byte buffer){
	colnum = 7-colnum;
	for (int i=0; i<8; ++i)
		figure[i][colnum] = (((1 << 7) >> i) & buffer) > 0;
}

void LedMatrix::setFigureString(String *fig){
	for (int i=0; i<8; ++i) setRowString(i, fig[i]);
}

void LedMatrix::setFigureByte(byte *fig){
	for (int i=0; i<8; ++i) setRowByte(i, fig[i]);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////

void LedMatrix::slideStringArray(String *text[], int state, char dir){

	if (!validStringSlide(text, state)){
		Serial.println("Swipe state out of range!!! Trying to reach "+String(state/8)+". letter out of "+String(getStringTextSize(text)));
		return;
	}
	switch (dir){
	case 'N':
		for (int i=0; i<8; ++i)
			setRowString(i, text[(i+state)/8]
							  	[(i+state)%8]);
		break;
	case 'S':
		for (int i=0; i<8; ++i)
			setRowString(i, text[abs(-7+i-state)/8]
								[7-abs(-7+i-state)%8]);
		break;
	case 'W':
		for (int i=0; i<8; ++i)
			for (int j=0; j<8; ++j)
				togglePixel(i, j, text[(j+state)/8]
					  				  [i]
					  				  [(j+state)%8]==this->on);
		break;
	case 'E':
		for (int i=0; i<8; ++i)
			for (int j=0; j<8; ++j)
				togglePixel(i, j, text[abs(-7+j-state)/8]
					  				  [i]
					  				  [7-abs(-7+j-state)%8]==this->on);
		break;
	default:
		Serial.println("Invalid direction for sliding text, choose from N, S, E, W!!!");
		break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////

void LedMatrix::slideByteArray(byte *text[], int state, char dir){

	if (!validByteSlide(text, state)){
		Serial.println("Swipe state out of range!!! Trying to reach "+String(state/8)+". letter out of "+String(getByteTextSize(text)));
		return;
	}

	switch (dir){
	case 'N':
		for (int i=0; i<8; ++i)
			setRowByte(i, text[(i+state)/8]
							  [(i+state)%8]);
		break;
	case 'S':
		for (int i=0; i<8; ++i)
			setRowByte(i, text[abs(-7+i-state)/8]
							  [7-abs(-7+i-state)%8]);
		break;
	case 'W':
		for (int i=0; i<8; ++i)
			for (int j=0; j<8; ++j)
				togglePixel(i, j, (text[(j+state)/8][i] & ((1 << 7) >> ((j+state)%8))) > 0);
		break;
	case 'E':
		for (int i=0; i<8; ++i)
			for (int j=0; j<8; ++j)
				togglePixel(i, j, ((text[abs(-7+j-state)/8][i] & (1 << (abs(-7+j-state)%8))) > 0) );
		break;
	default:
		Serial.println("Invalid direction for sliding text, choose from (N, S, E, W)!!!");
		break;
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////

int LedMatrix::getStringTextSize(String *text[]){
	int textsize = 0;
	while (text[textsize++] != nullptr);
	return --textsize;
}

int LedMatrix::getByteTextSize(byte *text[]){
	int textsize = 0;
	while (text[textsize++] != nullptr);
	return --textsize;
}

bool LedMatrix::validStringSlide(String *text[], int state){
	int textsize = getStringTextSize(text);
	return (state-1)/8<textsize-1 && (textsize!=1 || state>0) && state >= 0;
}

bool LedMatrix::validByteSlide(byte *text[], int state){
	int textsize = getByteTextSize(text);
	return (state-1)/8<textsize-1 && (textsize!=1 || state>0) && state >= 0;
}

//////////////////////////////////////////////////////////////////////////////////////////////////

void LedMatrix::update(){
	for (byte i = 0; i < 8; ++i){
		digitalWrite(row[i], HIGH);
		for (byte j = 0; j < 8; ++j){
			digitalWrite(col[j], !figure[i][j]);
			delayMicroseconds(100);
			digitalWrite(col[j], 1);
		}
		digitalWrite(row[i], LOW);
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void LedMatrix::setRowPorts(byte p1,
							byte p2,
							byte p3,
							byte p4,
							byte p5,
							byte p6,
							byte p7,
							byte p8){
	row[3] = p8;
	row[1] = p7;
	col[1] = p6;
	col[2] = p5;
	row[0] = p4;
	col[4] = p3;
	row[2] = p2;
	row[5] = p1;
	for (byte i = 0; i < 8; ++i)
        pinMode(row[i], OUTPUT);
}

void LedMatrix::setColumnPorts (byte p1,
					 			byte p2,
					 			byte p3,
					 			byte p4,
					 			byte p5,
					 			byte p6,
					 			byte p7,
					 			byte p8){
	col[7] = p8;
	col[6] = p7;
	row[6] = p6;
	col[0] = p5;
	row[4] = p4;
	col[5] = p3;
	col[3] = p2;
	row[7] = p1;
	for (byte i = 0; i < 8; ++i)
        pinMode(col[i], OUTPUT);
}

String* figureStringFromTxt(String filename){
    /*file.open(filename);
    char* row;
    char text_on, text_off;
    try{
		file.getline(row, 4);
		if (row[0]=='O'&&
			row[1]=='N'){
			if(row[2]==':')
				text_on = row[3];
			else {
				Serial.writeln("Error in \""+filename+".txt\", missing colon (:) after ON!");
				return nullptr;
			}
		}
		else {
			Serial.writeln("Error in \""+filename+".txt\", you must specify the ON character (correctly)!");
			return nullptr;
		}

		file.getline(row, 5);
		if (row[0]=='O'&&
			row[1]=='F'&&
			row[2]=='F'){
			if(row[3]==':')
				text_off = row[4];
			else {
				Serial.writeln("Error in \""+filename+".txt\", missing colon (:) after OFF!");
				return nullptr;
			}
		}
		else {
			Serial.writeln("Error in \""+filename+".txt\", you must specify the OFF character (correctly)!");
			return nullptr;
		}

		String* fig = new String[8];
		for (byte i=0; i<8; ++i){
			file.getline(row, 8);
			fig[i] = String(row);
		}
		return fig;
    }
    catch (int e){

    }*/
}
