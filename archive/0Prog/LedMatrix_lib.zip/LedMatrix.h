#ifndef LEDMATRIX_H
#define LEDMATRIX_H
#include "Arduino.h"

class LedMatrix{
private:
	byte *row, *col;
	char on, off;
	bool **figure;
	//ifstream file;

	int getStringTextSize(String *[]);
	int getByteTextSize(byte *[]);

public:

	LedMatrix();
	~LedMatrix();

	void clear();

	void togglePixel(byte, byte, bool);

	void setOnOffChars(char, char);

	void setRowString(byte, String);
	void setRowByte(byte, byte);
	void setColumnString(byte, String);
	void setColumnByte(byte, byte);

	void setFigureString(String*);
	void setFigureByte(byte*);
	String* figureStringFromTxt(String filename);

	void slideStringArray(String *[], int, char);
	void slideByteArray(byte *[], int, char);

	bool validStringSlide(String *[], int);
	bool validByteSlide(byte *[], int);

	void setRowPorts    (byte,byte,byte,byte,byte,byte,byte,byte); // 8 db
	void setColumnPorts (byte,byte,byte,byte,byte,byte,byte,byte); // 8 db

	void update();
};

class Figure : public LedMatrix {
	Figure multipleFiguresFromTxt(String filename);
};

#endif // LEDMATRIX_H_INCLUDED
