from kiwi_pie.util.property import Property


class MyClass:
    my_property = Property()


def test_property():
    my_instance = MyClass()

    # Test setting and getting the property value
    my_instance.my_property = 42
    assert my_instance.my_property == 42

    # Test subscribing to property changes
    def on_my_property_changed(value):
        assert value == 43

    my_instance.on_my_property(on_my_property_changed)
    my_instance.my_property = 43

    # Test unsubscribing from property changes
    my_instance.ignore_my_property(on_my_property_changed)
    my_instance.my_property = 44
