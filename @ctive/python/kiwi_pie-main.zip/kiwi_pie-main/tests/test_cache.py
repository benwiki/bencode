import time
from typing import Any

import pytest

from kiwi_pie.util.cache import cache


@cache(sync=True, suppress=ValueError)
def _do_work(x: Any) -> int:
    if not isinstance(x, int):
        raise TypeError("x must be an int")
    if x == 3:
        raise ValueError("3 is not a valid value")
    return x * 2


def test_cache_suppress():
    with pytest.raises(TypeError):
        _do_work("hello")
    assert _do_work(1) == 2
    assert _do_work(2) == 4
    assert _do_work(3) is None


_countval = 0


@cache(sync=True)
def _counter(x: int) -> int:
    global _countval
    _countval += 1
    return _countval


def test_cache_sync():
    assert _counter(0) == 1
    assert _counter(0) == 1
    assert _counter(1) == 2
    assert _counter(1) == 2
    assert _counter(0) == 1
    assert _counter(1) == 2
    assert _counter(2) == 3
    assert _counter(2) == 3


_countval2 = 0


@cache(sync=True, dur_ms=0)
def _counter2() -> int:
    global _countval2
    _countval2 += 1
    return _countval2


def test_cache_dur():
    assert _counter2() == 1
    time.sleep(0.001)  # ensure 1ms goes by
    assert _counter2() == 2
