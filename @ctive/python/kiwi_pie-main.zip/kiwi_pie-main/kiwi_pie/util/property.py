import asyncio
from inspect import iscoroutine
from typing import Awaitable, Callable, Generic, TypeVar

_T = TypeVar("_T")


class Property(Generic[_T]):
    def __set_name__(self, owner: type, name: str) -> None:
        def add_observer(obj, observer: Callable[[_T], Awaitable[None] | None]):
            if not hasattr(obj, self.obs):
                setattr(obj, self.obs, [])
            getattr(obj, self.obs).append(observer)

        def remove_observer(obj, observer: Callable[[_T], Awaitable[None] | None]):
            getattr(obj, self.obs).remove(observer)

        self.value = f"_{name}"  # pylint: disable=attribute-defined-outside-init
        self.obs = f"_{name}_obs"  # pylint: disable=attribute-defined-outside-init

        # TODO: investigate if on_{name} can be typed
        setattr(owner, f"on_{name}", add_observer)
        setattr(owner, f"ignore_{name}", remove_observer)

    def __get__(self, obj, objtype=None) -> _T:
        if obj is None:
            raise AttributeError("unreadable attribute")
            # return self
        return getattr(obj, self.value)

    def __set__(self, obj, value: _T):
        setattr(obj, self.value, value)
        for observer in getattr(obj, self.obs, []):
            retval = observer(value)
            if iscoroutine(retval):
                asyncio.create_task(retval)
