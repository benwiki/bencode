from typing import Iterable, TypeVar

T = TypeVar("T")


def get_difference(
    new_version: Iterable[T], old_version: Iterable[T]
) -> tuple[set[T], set[T]]:
    """First set: elements to add. Second set: elements to remove."""
    return (
        set(new_version) - set(old_version),
        set(old_version) - set(new_version),
    )
