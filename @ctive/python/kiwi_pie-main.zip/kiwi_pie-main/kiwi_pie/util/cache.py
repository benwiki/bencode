"""
This module provides a decorator that caches the results of a function for a specified duration.

Functions:
    cache: Decorator that caches the results of a function for a specified duration.
"""

import pickle
from functools import wraps
from time import time_ns
from typing import Awaitable, Callable, Literal, ParamSpec, TypeVar, overload

_P = ParamSpec("_P")
_R = TypeVar("_R")


@overload
def cache(
    *,
    dur_ms: int = 60_000 * 60 * 24 * 14,
    version: int = 0,
) -> Callable[[Callable[_P, Awaitable[_R]]], Callable[_P, Awaitable[_R]]]:
    ...


@overload
def cache(
    *,
    dur_ms: int = 60_000 * 60 * 24 * 14,
    version: int = 0,
    suppress: tuple[type[BaseException], ...] | type[BaseException],
) -> Callable[[Callable[_P, Awaitable[_R]]], Callable[_P, Awaitable[_R | None]]]:
    ...


@overload
def cache(
    *,
    dur_ms: int = 60_000 * 60 * 24 * 14,
    version: int = 0,
    sync: Literal[True],
) -> Callable[[Callable[_P, _R]], Callable[_P, _R]]:
    ...


@overload
def cache(
    *,
    dur_ms: int = 60_000 * 60 * 24 * 14,
    version: int = 0,
    suppress: tuple[type[BaseException], ...] | type[BaseException],
    sync: Literal[True],
) -> Callable[[Callable[_P, _R]], Callable[_P, _R | None]]:
    ...


def cache(
    *,
    dur_ms: int = 60_000 * 60 * 24 * 14,
    version: int = 0,
    suppress: tuple[type[BaseException], ...] | type[BaseException] = (),
    sync: bool = False,
) -> Callable[[Callable[_P, Awaitable[_R]]], Callable[_P, Awaitable[_R | None]]]:
    """
    Decorator that caches the results of a function for a specified duration.

    Args:
        dur_ms (int): The duration of the caching in milliseconds. (default 14 days)

        version (int): The version of the cache. (default 0)

        suppress (tuple[type[BaseException], ...]): Exceptions to suppress. (default ())

    Returns:
        Callable[[Callable[_P, Awaitable[_R]]], Callable[_P, Awaitable[_R | None]]]:
        The decorated function.
    """

    def wrapper(fn):  # pylint: disable=invalid-name
        c = {}  # pylint: disable=invalid-name

        if sync:

            @wraps(fn)
            def res(*args, **kwargs):
                k = pickle.dumps((fn.__module__, fn.__name__, *args, kwargs), 0)
                t = time_ns() // 1_000_000  # pylint: disable=invalid-name
                if c.get(k, ((0, 0),))[0] < (version, t - dur_ms):
                    try:
                        c[k] = ((version, t), fn(*args, **kwargs))
                    except (
                        (suppress,) if isinstance(suppress, BaseException) else suppress
                    ):
                        return None
                return c[k][1]

        else:

            @wraps(fn)
            async def res(*args, **kwargs):
                k = pickle.dumps((fn.__module__, fn.__name__, *args, kwargs), 0)
                t = time_ns() // 1_000_000  # pylint: disable=invalid-name
                if c.get(k, ((0, 0),))[0] < (version, t - dur_ms):
                    try:
                        c[k] = ((version, t), await fn(*args, **kwargs))
                    except (
                        (suppress,) if isinstance(suppress, BaseException) else suppress
                    ):
                        return None
                return c[k][1]

        return res

    return wrapper
