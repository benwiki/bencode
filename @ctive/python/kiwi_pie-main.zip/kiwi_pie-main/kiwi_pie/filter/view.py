import pkg_resources
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button

from kiwi_pie.filter.constants import COLOR_BUTTONS, HEIGHT_KEYWORD
from kiwi_pie.filter.viewmodel import FilterViewModel

Builder.load_file(pkg_resources.resource_filename(__name__, "filterView.kv"))


class FilterView(BoxLayout):
    """
    View of the filter item. It has all the widgets and otehr graphics of the
    filter that the user needs to see but does not do anything fancy itself.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.view_model = FilterViewModel()

    def on_event_switch_clicked(self, _, value):
        """Handle change in showing event markers"""
        self.view_model.show_events(value)

    def on_border_switch_clicked(self, _, value):
        """Handle change in showing borders"""
        self.view_model.show_borders(value)

    def create_keyword_button(self, text: str, box, button_type: str):
        """Create a button for a selected keyword or date"""
        new_button = Button(
            text=text,
            size_hint_y=None,
            height=HEIGHT_KEYWORD,
            background_color=COLOR_BUTTONS,
        )
        box.add_widget(new_button)
        match button_type:
            case "date":
                new_button.bind(on_release=self.remove_date)
            case "keyword":
                new_button.bind(on_release=self.remove_keyword)

    def create_country_button(self, name: str, box):
        """ "Create buttons for a selected country"""
        button = Button(
            text=name,
            size_hint_y=None,
            height=HEIGHT_KEYWORD,
            background_color=COLOR_BUTTONS,
        )
        reloader = Button(
            text="Reload!",
            size_hint_y=None,
            size_hint_x=0.7,
            height=HEIGHT_KEYWORD,
            background_color=COLOR_BUTTONS,
        )
        new_buttons = BoxLayout(
            size_hint_y=None, height=HEIGHT_KEYWORD, orientation="horizontal"
        )
        new_buttons.add_widget(button)
        new_buttons.add_widget(reloader)
        box.add_widget(new_buttons)

        button.bind(on_release=self.remove_country)
        reloader.bind(on_release=lambda _: self.reload_country(name))

    def add_keyword(self, keyword: str):
        """Add a keyword to the filter"""
        self.ids.keyword_input.text = ""
        words_to_add = self.view_model.add_keyword(keyword)
        # Create buttons for keywords
        # for word in words_to_add:
        self.create_keyword_button(words_to_add, self.ids.keyword_box, "keyword")

    def add_dates(self, date):
        """Add a date to the filter"""
        if not self.view_model.set_date(date):
            self.ids.date_input.text = ""
            self.ids.date_input.hint_text = "Invalid date! Use dd.mm.yyyy"
        else:
            self.create_keyword_button(date, self.ids.date_box, "date")
            self.ids.date_input.text = ""

    def remove_keyword(self, instance):
        """Remove a clicked keyword from the filter"""
        self.view_model.remove_keywords(instance.text)
        self.ids.keyword_box.remove_widget(instance)

    def remove_date(self, instance):
        """Remove a clicked date from the filter"""
        self.view_model.remove_date(instance.text)
        self.ids.date_box.remove_widget(instance)

    async def select_country(self, country: str):
        """Select a country of which data is shown."""
        country = country.capitalize()

        valid = await self.view_model.select_country(country)
        self.ids.country_input.text = ""

        if valid:
            self.create_country_button(country, self.ids.country_input_box)
            self.ids.country_input.hint_text = "Enter country name here"
        else:
            self.ids.country_input.hint_text = "Invalid country! Try again"

    def remove_country(self, country_button):
        """Remove a clicked country from the filtering options"""
        self.view_model.remove_country(country_button.text)
        self.ids.country_input.text = ""
        self.ids.country_input.hint_text = "Enter country name here"
        self.ids.country_input_box.remove_widget(country_button.parent)

    def reload_country(self, name):
        self.view_model.reload_country(name)

    def clear_filters(self):
        """Clear all filters from the view and the model"""
        self.view_model.clear_filters()

        self.ids.country_input.text = ""
        self.ids.country_input.hint_text = "Enter country name here"
        self.ids.country_input_box.clear_widgets()

        self.ids.date_input.text = ""
        self.ids.date_input.hint_text = "Enter date in dd.mm.yyyy"
        self.ids.date_box.clear_widgets()

        self.ids.keyword_input.text = ""
        self.ids.keyword_input.hint_text = "Enter keywords here"
        self.ids.keyword_box.clear_widgets()

        self.ids.event_marker_switch.active = False
        self.ids.border_switch.active = False

    def save(self):
        """ "Save the current filter"""
        self.view_model.save_filter()

    def fetch_filter(self):
        """ "Fetch a saved filter and update the view accordingly"""
        self.clear_filters()

        data = self.view_model.get_saved_data()
        self.ids.border_switch.active = data["show_borders"]
        self.ids.event_marker_switch.active = data["show_events"]

        for word in data["keywords"]:
            self.create_keyword_button(word, self.ids.keyword_box, "keyword")
        for country in data["countries"]:
            self.create_country_button(country, self.ids.country_input_box)
        for date in data["date"]:
            self.create_keyword_button(date, self.ids.date_box, "date")
