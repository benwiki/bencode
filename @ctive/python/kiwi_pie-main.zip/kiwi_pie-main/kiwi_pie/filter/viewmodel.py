from datetime import datetime

from kiwi_pie.filter.model import FilterModel
from kiwi_pie.map.model import BorderModel


class FilterViewModel:
    """
    This is the view model for the filter and controls the view. It also
    sends updates to the filter model and other view models.
    """

    def __init__(self):
        self.__model = FilterModel()

    def show_events(self, show):
        """Handle change in showing event markers"""
        self.__model.update_events(show)

    def show_borders(self, show):
        """Handle change in showing borders"""
        self.__model.update_borders(show)

    def add_keyword(self, keyword: str):
        """Add keywords to the model. Return the added keywords."""
        self.__model.add_keyword(keyword)
        return keyword

    def remove_keywords(self, word):
        """ "Remove a keyword from the model"""
        self.__model.remove_keywords(word)

    def remove_date(self, date):
        """Remove a date from the filter"""
        self.__model.remove_date(date)

    def remove_country(self, country):
        """Remove a country from the filter"""
        self.__model.remove_country(country)

    def reload_country(self, country):
        """Update borders"""
        self.__model.reload_country(country)

    def validate_date(self, date):
        """Attempt to parse the date. Return true if valid, false if not."""
        try:
            datetime.strptime(date, "%d.%m.%Y")
            return True
        except ValueError:
            return False

    def set_date(self, date):
        """Update the date in the model. Return true if valid, false if not."""
        if self.validate_date(date):
            self.__model.add_date(date)
            return True

        return False

    async def select_country(self, country: str):
        """Select a country to filter by. Return true if country exists
        in the API, false if not."""
        # check if country exists
        country_exists = await BorderModel().valid_country(country)
        if country_exists:
            # update model
            self.__model.select_country(country)
        return country_exists

    def clear_filters(self):
        """Clear all filters from the model"""
        self.__model.clear_filters()

    def save_filter(self):
        """Make model save the filter locally"""
        self.__model.save_filter()

    def get_saved_data(self):
        """Get the saved data from the model."""
        return self.__model.get_saved_data()
