# from ast import List
import json
from typing import Callable

from kiwi_pie.util.property import Property
from kiwi_pie.util.singleton import Singleton

FILTER_FILE = "filter.json"


class FilterModel(metaclass=Singleton):
    """
    Model of the filter ie. stores the filter options.
    """

    keywords = Property[list[str]]()
    dates = Property[list[str]]()
    show_borders = Property[bool]()
    show_events = Property[bool]()
    countries = Property[list[str]]()
    reload = Property[str]()

    on_keywords: Callable[[Callable[[list[str]], None]], None]
    on_dates: Callable[[Callable[[list[str]], None]], None]
    on_show_borders: Callable[[Callable[[bool], None]], None]
    on_show_events: Callable[[Callable[[bool], None]], None]
    on_countries: Callable[[Callable[[list[str]], None]], None]
    on_reload: Callable[[Callable[[str], None]], None]

    def __init__(self):
        self.keywords = []
        self.dates = []
        self.show_borders = True
        self.show_events = True
        self.countries = []

    def update_events(self, hide):
        """ "Update whether events markers are shown or not"""
        self.show_events = hide

    def update_borders(self, hide):
        """ "Update whether borders are shown or not"""
        self.show_borders = hide

    def add_keyword(self, keyword: str):
        """ "Add a keyword to the filter options"""
        self.keywords += [keyword]

    def remove_keywords(self, keyword: str):
        """Remove a keyword from the filter options"""
        try:
            self.keywords.remove(keyword)
            self.keywords = self.keywords  # trigger update
        except ValueError:
            pass

    def add_date(self, date: str):
        """Add a date to the filter options"""
        self.dates += [date]

    def remove_date(self, date: str):
        """Remove a date from the filter options"""
        try:
            self.dates.remove(date)
            self.dates = self.dates  # trigger update
        except ValueError:
            pass

    def select_country(self, country: str):
        """Add a country to the filter options"""
        self.countries += [country]

    def remove_country(self, country: str):
        """Remove a country from the filter options"""
        self.countries = [c for c in self.countries if c != country]

    def reload_country(self, country: str):
        """Update borders"""
        self.reload = country

    def clear_filters(self):
        """Clear all filters from the model"""
        self.keywords = []
        self.dates = []
        self.show_events = False
        self.show_borders = False
        self.countries = []

    def save_filter(self):
        """Save the current filter into local json file"""
        data = {
            "keywords": self.keywords,
            "dates": self.dates,
            "show_borders": self.show_borders,
            "show_events": self.show_events,
            "countries": self.countries,
        }

        with open(FILTER_FILE, "w", encoding="U8") as file:
            json.dump(data, file)

    def load_filter(self):
        """Read the saved filter optinos to the model"""
        try:
            with open(FILTER_FILE, "r", encoding="U8") as file:
                data = json.load(file)
        except FileNotFoundError:
            data = {}

        self.keywords = data.get("keywords", [])
        self.dates = data.get("dates", [])
        self.countries = data.get("countries", [])
        self.update_borders(data.get("show_borders", False))
        self.update_events(data.get("show_events", False))

    def get_saved_data(self):
        """Load and return the saved filter options"""
        self.load_filter()

        return {
            "keywords": self.keywords,
            "dates": self.dates,
            "show_borders": self.show_borders,
            "show_events": self.show_events,
            "countries": self.countries,
        }
