import pkg_resources
from kivy.clock import Clock
from kivy.graphics import Color, Line
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.widget import WidgetException
from kivy_garden.mapview import MapMarkerPopup, MapSource, MapView

from kiwi_pie.map.border import CountryBorder
from kiwi_pie.map.marker import Marker
from kiwi_pie.map.viewmodel import MapViewModel
from kiwi_pie.util.algo import get_difference

Builder.load_file(pkg_resources.resource_filename(__name__, "mapView.kv"))

Period = tuple[int | None, int | None]


class MapViewCustom(MapView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.map_vm = MapViewModel()
        self.map_vm.on_borders(self._update_borders)
        self.map_vm.on_markers(self._update_markers)
        self.map_vm.on_show_borders(self._toggle_borders)
        self.map_vm.on_show_markers(self._toggle_markers)

        self.marker_objects = []
        self.line_coords: dict[Line, list[tuple[float, float]]] = {}
        self.hidden_lines: dict[Line, list[tuple[float, float]]] = {}
        self.country_lines: dict[str, dict[Period, Line]] = {}
        self.show_border_lines = True
        self.map_source = MapSource(min_zoom=2, max_zoom=19)
        self.to_add = self.to_remove = []
        self.border_infos: dict[str, BoxLayout] = {}

        Clock.schedule_interval(self._update_border_lines, 1 / 100)

    def _update_border_lines(self, _=None):
        """Is called very frequently and updates the border lines."""
        if self.show_border_lines and self.line_coords:
            for line, realpts in self.line_coords.items():
                line.points = [
                    self.get_window_xy_from(lon, lat, self.zoom) for lat, lon in realpts
                ]

    def on_zoom(self, instance, zoom):
        super().on_zoom(instance, zoom)
        self._update_border_lines()

    def _update_borders(self, new_country_borders: dict[str, list[CountryBorder]]):
        """Updates the borders on the map to reflect the borders that are currently selected."""
        self.to_add, self.to_remove = get_difference(
            new_country_borders, self.country_lines
        )
        self._remove_old_borders()
        self._add_new_borders(new_country_borders)

    def _remove_old_borders(self):
        """Removes the borders from the map that are no longer selected."""
        for country in self.to_remove:
            for _, line in self.country_lines[country].items():
                self.canvas.remove(line)
                self.line_coords.pop(line)
            self.country_lines.pop(country)
            self._remove_infos_for_country(country)

    def _remove_infos_for_country(self, country):
        """Removes the border info for a country."""
        ctry_box = self.border_infos[country]
        # for _, info in period_labels.items():
        #     period_box.remove_widget(info)
        self.ids.country_border_info_box.remove_widget(ctry_box)
        self.border_infos.pop(country)

    def _add_new_borders(self, new_country_borders):
        """Adds the new borders to the map. Look at this beauty. Isn't it gorgeous?"""
        for country, borders in new_country_borders.items():
            if country in self.to_add:
                for border in borders:
                    if border.visible:
                        self._add_border_to_canvas(border, country)
                self._add_country_info(borders, country)

    def _add_border_to_canvas(self, border: CountryBorder, country):
        """Adds a border to the canvas."""
        with self.canvas:
            Color(*border.color)

            line = Line(width=border.width)
            self.country_lines[country] = self.country_lines.get(country, {}) | {
                border.period: line
            }

            pts, coords = self.map_vm.calculate_border_points(
                border,
                self.zoom,
                lambda lat, lon: self.get_window_xy_from(lon, lat, self.zoom),
            )
            self.line_coords[line] = coords
            if self.map_vm.show_borders:
                line.points = pts
        print(border.country, "loaded!")

    def _add_country_info(self, borders, country):
        """Adds the border info for a country."""
        num_periods = len(borders)
        period_label_height = 25  # Adjust the height of one label as needed
        ctry_label_height = 30  # Adjust the height of the country label as needed

        ctry_box = BoxLayout(
            orientation="vertical",
            size_hint=(1, None),
            # Set the height of the BoxLayout based on the number of period labels
            height=((num_periods + 1) * period_label_height) + ctry_label_height,
        )
        ctry_label = Button(
            text=country,
            color=(1, 1, 1, 1),
            size_hint=(1, None),
            height=ctry_label_height,
            background_color=(0, 0, 0, 1),
        )
        period_box = BoxLayout(
            orientation="vertical",
            size_hint=(1, None),
            # Set the height of the BoxLayout based on the number of period labels
            height=((num_periods + 1) * period_label_height),
        )
        ctry_box.add_widget(ctry_label)
        ctry_box.add_widget(period_box)
        for period_label in self._get_period_labels(borders, period_label_height):
            period_box.add_widget(period_label)

        self.border_infos[country] = ctry_box
        self.ids.country_border_info_box.add_widget(ctry_box)

    def _get_period_labels(self, borders: list[CountryBorder], height: int):
        """Returns the period labels for a border."""
        return [
            Button(
                text=f"{border.period[0] or '...'} - {border.period[1] or '...'}",
                color=(1, 1, 1, 1),
                size_hint=(1, None),
                height=height,
                on_release=lambda _, b=border: self._toggle_border_visibility(b),
                background_color=border.color,
            )
            for border in borders
        ] + [Label(size_hint=(1, None), height=height)]

    def _toggle_border_visibility(self, border: CountryBorder):
        """Toggles the visibility of a border."""
        border.visible = not border.visible
        if border.visible:
            line = self.country_lines[border.country][border.period]
            coords = self.hidden_lines.pop(line)
            self.line_coords.update({line: coords})
        else:
            line = self.country_lines[border.country][border.period]
            line.points = []
            coords = self.line_coords.pop(line)
            self.hidden_lines.update({line: coords})
        self.show_border_lines = True

    def _update_markers(self, new_markers: list[Marker]):
        """Updates the markers on the map to reflect the events that happened on a given day."""
        self.clear_widgets(self.marker_objects)
        self.marker_objects.clear()
        for marker in new_markers:
            marker_obj = MapMarkerPopup(
                lat=marker.lat,
                lon=marker.lon,
            )
            marker_obj.add_widget(
                Label(
                    text=marker.title + "\n" + marker.description,
                    color=(0, 0, 0, 1),
                )
            )
            self.marker_objects.append(marker_obj)
            self.add_widget(marker_obj)

    def _toggle_borders(self, show: bool):
        """Toggles the borders on the map."""
        self.show_border_lines = show
        if not show:
            self._hide_border_lines()

    def _hide_border_lines(self):
        """Hides the border lines."""
        for line in self.line_coords:
            line.points = []

    def _toggle_markers(self, show: bool):
        """Toggles the markers on the map."""
        if show:
            self._show_markers()
        else:
            self._hide_markers()

    def _show_markers(self):
        """Shows the markers on the map."""
        try:
            for marker in self.marker_objects:
                self.add_widget(marker)
        except WidgetException:
            pass

    def _hide_markers(self):
        """Hides the markers on the map."""
        self.clear_widgets(self.marker_objects)


def peak(object) -> str:
    s = ""
    match object:
        case str():
            s += object
        case list():
            s += "["
            for item in object[:3]:
                s += peak(item)
                s += ", "
            s += "]"
        case dict():
            s += "{"
            for key, value in list(object.items())[:3]:
                s += peak(key)
                s += ": "
                s += peak(value)
                s += ", "
            s += "}"
        case tuple():
            s += "("
            for item in object[:3]:
                s += peak(item)
                s += ", "
            s += ")"
        case set():
            s += "{"
            for item in list(object)[:3]:
                s += peak(item)
                s += ", "
            s += "}"
        case float() | int() | bool() | None:
            s += str(object)
        case object:
            s += object.__class__.__name__
    return s
