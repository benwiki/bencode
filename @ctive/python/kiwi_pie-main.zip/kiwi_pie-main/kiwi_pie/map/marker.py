from dataclasses import dataclass


@dataclass
class Marker:
    """This is a class to represent geographical data for a marker.

    Attributes:
    - lat: the latitude of the marker
    - lon: the longitude of the marker
    - title: the title of the marker
    - description: the description of the marker
    """

    lat: float = 0.0
    lon: float = 0.0
    title: str = ""
    description: str = ""
