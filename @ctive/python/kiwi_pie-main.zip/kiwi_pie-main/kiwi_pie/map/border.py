from dataclasses import dataclass
from typing import Iterable


@dataclass
class CountryBorder:
    """This is a class to represent geographical data for the border of a country.
    Values:
    - country: the country name
    - border: a list of points that make up the border of the country
    - color: the color of the border
    - width: the width of the border
    - alpha: the opacity of the border
    - visible: whether the border is visible or not
    """

    country: str
    coords: Iterable[tuple[float, float]]
    period: tuple[int | None, int | None]
    color: tuple = (1, 0, 0, 1)
    width: float = 2.0
    visible: bool = True
