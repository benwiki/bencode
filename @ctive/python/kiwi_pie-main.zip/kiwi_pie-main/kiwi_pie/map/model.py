import abc
import re
from math import hypot
from typing import Callable

import aiohttp
from kiwi_pie.events.onthisdayevent import OnThisDayEvent
from kiwi_pie.map.border import CountryBorder
from kiwi_pie.map.marker import Marker
from kiwi_pie.util.algo import get_difference
from kiwi_pie.util.cache import cache
from kiwi_pie.util.colors import Colors
from kiwi_pie.util.property import Property
from kiwi_pie.util.singleton import Singleton


class BorderAPI:
    """An interface for an API that fetches borders for countries."""

    @abc.abstractmethod
    async def fetch_borders(self, country: str) -> list[CountryBorder]:
        """Fetches the borders in different times for a given country.
        E.g. for Germany, it might return a list of borders for the years
        (1990-) and (1940-1941)."""
        raise NotImplementedError


class OpenHistoricalMapAPI:
    async def fetch_borders(self, country: str) -> dict | None:
        """Fetches the borders for a given country."""
        return await fetch_borders(country)


@cache()
async def fetch_borders(country: str) -> dict | None:
    async with aiohttp.ClientSession() as session:
        url = "https://nominatim-api.openhistoricalmap.org/"
        url += f"search.php?q={country}&polygon_geojson=1&format=jsonv2"
        async with session.get(url) as response:
            if response.status != 200:
                return None

            return await response.json()


class OpenHistoricalMapAdapter(BorderAPI):
    def __init__(self):
        """An adapter for the OpenHistoricalMap API."""
        self.api = OpenHistoricalMapAPI()
        self.period_regex = re.compile(r".*(\(\d*-\d*\)).*")
        self.colors = None

    async def fetch_borders(self, country: str) -> list[CountryBorder]:
        """Fetches the border for a given country."""
        json_response = await self.api.fetch_borders(country)
        if not json_response:
            return []

        self.colors = Colors()
        borders: list[CountryBorder] = []
        for border_in_time in json_response:
            if border := self._to_border(border_in_time, country):
                borders.append(border)
        return borders

    async def valid_country(self, country: str) -> bool:
        """Checks if a country is valid."""
        return await self.fetch_borders(country) != []

    def _to_border(self, border_in_time: dict, country: str) -> CountryBorder | None:
        """Converts a border in time from the OpenHistoricalMap API to a CountryBorder."""
        geojson = border_in_time["geojson"]
        if geojson["type"] == "Polygon":
            coords = geojson["coordinates"][0]
        elif geojson["type"] == "MultiPolygon":
            coords = (elem for lst in geojson["coordinates"][0] for elem in lst)
        else:
            return None
        period = self._name_to_period(border_in_time["display_name"])
        if not period:
            return None
        return CountryBorder(country, coords, period, self.colors.next_color())  # type: ignore

    def _name_to_period(self, name: str) -> tuple[int | None, int | None] | None:
        """Converts a name like "Germany (1990-), Germany" to a pair of ints."""
        period = self.period_regex.match(name)
        if not period:
            return None
        return self._text_to_period(period.group(1))

    def _text_to_period(self, text: str) -> tuple[int | None, int | None]:
        """Converts a period string like "(2020-2021)" to a pair of ints.
        If a value is None, the string looks like "(2020-)" or "(-2020)"."""
        period = text.strip("()").split("-")
        return (self._default_int(period[0]), self._default_int(period[1]))

    def _default_int(self, value: str) -> int | None:
        """Converts a string to an int, or returns None if it can't."""
        return int(value) if value.isnumeric() else None


class BorderModel(metaclass=Singleton):
    borders = Property[dict[str, list[CountryBorder]]]()
    on_borders: Callable[[Callable[[dict[str, list[CountryBorder]]], None]], None]

    def __init__(self):
        self.adapter = OpenHistoricalMapAdapter()
        self.borders = {}

    async def fetch_borders(self, countries: list[str]):
        """Fetches the borders for a list of countries."""
        to_add, to_remove = get_difference(countries, self.borders)
        print(to_add, to_remove)

        new_borders = {k: v for k, v in self.borders.items() if k not in to_remove}

        for country in to_add:
            borderlist = await self.adapter.fetch_borders(country)
            if not borderlist:
                print(f"[WARNING] Invalid country: {country}")
                return
            new_borders[country] = borderlist

        self.borders = new_borders

    async def valid_country(self, country: str) -> bool:
        """Checks if a country is valid."""
        return await self.adapter.valid_country(country)

    def get_markers(self, events: list[OnThisDayEvent]) -> list[Marker]:
        return [
            Marker(
                lat=page.coordinates["lat"],
                lon=page.coordinates["lon"],
                title=page.normalizedtitle,
                description=page.description,
            )
            for event in events
            for page in event.pages
            if page.coordinates and page.normalizedtitle and page.description
        ]

    async def reload_country(self, country: str):
        """Reloads the borders for a country."""
        self.borders = {k: v for k, v in self.borders.items() if k != country}
        borders = await self.adapter.fetch_borders(country)
        self.borders = {**self.borders, country: borders}

    def calculate_border_points(
        self,
        border: CountryBorder,
        threshold: int,
        get_xy: Callable[[float, float], tuple[float, float]],
    ) -> tuple[list[tuple[float, float]], list[tuple[float, float]]]:
        """Calculates the map points and coordinates for a border."""
        pts: list[tuple[float, float]] = []
        coords: list[tuple[float, float]] = []
        for lat, lon in border.coords:
            x, y = get_xy(lon, lat)
            if not pts:
                pts.append((x, y))
                continue

            old_x, old_y = pts[-1]
            dist = hypot(x - old_x, y - old_y)
            if dist > threshold:
                pts.append((x, y))
                coords.append((lat, lon))
        return pts, coords
