import asyncio
from typing import Callable

from kiwi_pie.events.model import EventsModel
from kiwi_pie.events.onthisdayevent import OnThisDayEvent
from kiwi_pie.filter.model import FilterModel
from kiwi_pie.map.border import CountryBorder
from kiwi_pie.map.marker import Marker
from kiwi_pie.map.model import BorderModel
from kiwi_pie.util.property import Property


class MapViewModel:
    """
    This is the view model for the map and controls the view. It also
    sends updates to the map model and other view models.
    """

    borders = Property[dict[str, list[CountryBorder]]]()
    markers = Property[list[Marker]]()
    show_borders = Property[bool]()
    show_markers = Property[bool]()

    on_borders: Callable[[Callable[[dict[str, list[CountryBorder]]], None]], None]
    on_markers: Callable[[Callable[[list[Marker]], None]], None]
    on_show_borders: Callable[[Callable[[bool], None]], None]
    on_show_markers: Callable[[Callable[[bool], None]], None]

    def __init__(self):
        self._border_model = BorderModel()
        self._border_model.on_borders(self._update_borders)

        self._events_model = EventsModel()
        self._events_model.on_events(self._update_event_markers)

        self._filter_model = FilterModel()
        self._filter_model.on_show_borders(self._toggle_borders)
        self._filter_model.on_show_events(self._toggle_markers)
        self._filter_model.on_countries(self._update_countries)
        self._filter_model.on_reload(self._reload_country)

        self.markers = []
        self.borders = {}
        self.show_markers = True
        self.show_borders = True

    def _update_borders(self, borders: dict[str, list[CountryBorder]]):
        """Updates the borders on the map to reflect the borders that are currently selected."""
        self.borders = borders

    def _update_event_markers(self, events: list[OnThisDayEvent]):
        """Updates the markers on the map to reflect the events that happened on a given day."""
        self.markers = self._border_model.get_markers(events)

    def _toggle_borders(self, show: bool):
        self.show_borders = show

    def _toggle_markers(self, show: bool):
        self.show_markers = show

    def _update_countries(self, countries: list[str]):
        """Updates the borders on the map to reflect the countries that are currently selected."""
        asyncio.create_task(self._border_model.fetch_borders(countries))

    def _reload_country(self, country: str):
        """Reloads the borders for a given country."""
        asyncio.create_task(self._border_model.reload_country(country))

    def calculate_border_points(
        self,
        border: CountryBorder,
        threshold: int,
        get_xy: Callable[[float, float], tuple[float, float]],
    ):
        """Calculates the map points and coordinates for a border."""
        return self._border_model.calculate_border_points(border, threshold, get_xy)
