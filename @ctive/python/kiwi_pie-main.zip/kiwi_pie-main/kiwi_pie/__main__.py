import asyncio

from kivy.app import App


class AppView(App):
    pass


if __name__ == "__main__":

    async def main():
        await AppView().async_run()

    asyncio.run(main())
