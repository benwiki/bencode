from typing import Literal, TypedDict

from attr import dataclass


@dataclass
class PageThumbnail:
    """
    A dataclass that represents the thumbnail of a Wikipedia page.
    """

    source: str
    width: int
    height: int


@dataclass
class OnThisDayPage:
    """
    A dataclass that represents a Wikipedia page that is related to an event
    that happened on a given day.
    """

    type: str | None = None
    title: str | None = None
    coordinates: dict | None = None
    displaytitle: str | None = None
    namespace: dict | None = None
    wikibase_item: str | None = None
    titles: dict | None = None
    pageid: int | None = None
    thumbnail: PageThumbnail | None = None
    originalimage: dict | None = None
    lang: str | None = None
    dir: str | None = None
    revision: str | None = None
    tid: str | None = None
    timestamp: str | None = None
    description: str | None = None
    description_source: str | None = None
    content_urls: dict | None = None
    extract: str | None = None
    extract_html: str | None = None
    normalizedtitle: str | None = None


@dataclass
class OnThisDayEvent:
    """
    A dataclass that represents an event that happened on a given day.
    """

    pages: list[OnThisDayPage]
    text: str | None = None
    year: int | None = None


OnThisDayType = (
    Literal["all"]
    | Literal["selected"]
    | Literal["births"]
    | Literal["deaths"]
    | Literal["events"]
    | Literal["holidays"]
)
