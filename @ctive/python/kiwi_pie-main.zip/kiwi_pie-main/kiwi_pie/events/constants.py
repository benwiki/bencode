import pkg_resources

COLOR_YEAR = "ffffffff"
COLOR_SEP = "aaaaaaff"
COLOR_TITLE = "ffffffff"
COLOR_DESC = "aaaaaaff"
COLOR_BACK = "111111ff"

THUMB_SIZE = 80
THUMB_PAD = 2
THUMB_DEF = {
    "source": pkg_resources.resource_filename(
        __name__, "657px-Wikipedia-logo-transparent.png"
    ),
    "width": 1200,
    "height": 1095,
}
