from dataclasses import dataclass
from typing import Callable

import aiohttp
from kiwi_pie.events.constants import THUMB_DEF
from kiwi_pie.events.onthisdayevent import (
    OnThisDayEvent,
    OnThisDayPage,
    OnThisDayType,
    PageThumbnail,
)
from kiwi_pie.util.cache import cache
from kiwi_pie.util.property import Property
from kiwi_pie.util.singleton import Singleton


@dataclass
class EventsModelInput:
    """
    A dataclass that represents the input to the `update_lazy` method of the
    `EventList` widget. It contains the month and day of the events to be
    displayed, as well as the type of events to be displayed.
    """

    month: int
    day: int
    type_: OnThisDayType = "all"


def _thumb_validate(thumb: dict | None) -> PageThumbnail:
    if thumb is not None:
        thumb = PageThumbnail(**thumb)
        ext = thumb.source.split(".")[-1]
        if ext in ("jpg", "jpeg", "png"):
            return thumb
    return PageThumbnail(**THUMB_DEF)


def _set(d, **kwargs):
    res = {**d}
    res.update(**kwargs)
    return res


class EventsModel(metaclass=Singleton):
    """The model for the events that happened on a given day. Singleton."""

    events = Property[list]()
    on_events: Callable

    def __init__(self):
        self.events = []

    def _parse_to_events(self, events: list[dict]) -> list[OnThisDayEvent]:
        """Parses the events returned by the Wikipedia API."""
        return [
            OnThisDayEvent(
                pages=[
                    OnThisDayPage(
                        **_set(
                            event_page,
                            thumbnail=_thumb_validate(event_page.get("thumbnail")),
                        ),
                    )
                    for event_page in event["pages"]
                ],
                text=event["text"],
                year=event["year"],
            )
            for event in events
        ]

    async def fetch_events(
        self, input_: EventsModelInput
    ) -> list[OnThisDayEvent] | None:
        events_raw = await fetch_events(input_)
        if not events_raw:
            return None
        self.events = self._parse_to_events(events_raw)
        return self.events


@cache()
async def fetch_events(input_: EventsModelInput) -> list[dict] | None:
    """Fetches the events that happened on a given day from Wikipedia."""
    type_, month, day = input_.type_, input_.month, input_.day
    async with aiohttp.ClientSession() as session:
        url = f"https://en.wikipedia.org/api/rest_v1/feed/onthisday/{type_}/{month:02}/{day:02}"
        async with session.get(url) as response:
            if response.status != 200:
                return None

            json_response = await response.json()
            return json_response["events"]
