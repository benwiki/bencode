from typing import Callable

from kiwi_pie.events.model import EventsModel, EventsModelInput
from kiwi_pie.events.onthisdayevent import OnThisDayEvent
from kiwi_pie.util.property import Property


class EventsViewModel:
    filter = Property[EventsModelInput]()
    events = Property[list[OnThisDayEvent]]()
    on_events: Callable
    on_filter: Callable

    def __init__(self):
        self.on_filter(self.update_events)
        self.model = EventsModel()
        self.events = []

    async def update_events(self, input_: EventsModelInput):
        self.events = await self.model.fetch_events(input_)
