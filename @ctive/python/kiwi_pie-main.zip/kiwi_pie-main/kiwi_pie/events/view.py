import re
from datetime import datetime
from typing import Iterable

import pkg_resources
from kivy.lang import Builder
from kivy.properties import ObjectProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView

from kiwi_pie.events.constants import COLOR_DESC, COLOR_SEP, COLOR_TITLE, COLOR_YEAR
from kiwi_pie.events.model import EventsModelInput
from kiwi_pie.events.onthisdayevent import OnThisDayEvent, OnThisDayPage
from kiwi_pie.events.viewmodel import EventsViewModel
from kiwi_pie.filter.model import FilterModel
from kiwi_pie.util.property import Property

Builder.load_file(pkg_resources.resource_filename(__name__, "events.kv"))


class OnThisDayPageWidget(BoxLayout):
    thumbnail = ObjectProperty()
    text = StringProperty()


def _keyword_predicate_map(x: str) -> str:
    pre, suf = r"\b", r"\b"
    if x.startswith("*"):
        pre, x = "", x[1:]
    if x.endswith("*"):
        suf, x = "", x[:-1]
    return f"{pre}{x}{suf}"


def _keyword_predicate(keywords: Iterable[str]):
    pat = re.compile("|".join(map(_keyword_predicate_map, keywords)), re.I)

    def pred(page: OnThisDayPage):
        return pat.search(page.titles.get("normalized", "")) or pat.search(
            page.description or page.extract
        )

    return pred


def _date_predicate_map(date: str):
    dt = datetime.strptime(date, "%d.%m.%Y")
    return f"{dt.year}-{dt.month:02}-{dt.day:02}"


def _date_predicate(dates: Iterable[str]):
    dates = list(map(_date_predicate_map, dates))
    if not dates:
        return lambda _: True

    def pred(page: OnThisDayPage):
        return any(map(page.timestamp.startswith, dates))

    return pred


class EventsView(ScrollView):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._viewmodel = EventsViewModel()
        self._filtermodel = FilterModel()
        self._filtermodel.on_keywords(self._on_keyword)
        self._filtermodel.on_dates(self._on_date)
        self._viewmodel.filter = EventsModelInput(month=3, day=1, type_="events")
        self._viewmodel.on_events(self._display_events)
        self._pkw = lambda _: True
        self._pdate = lambda _: True

    async def _on_keyword(self, keywords):
        self._pkw = _keyword_predicate(keywords)
        await self._display_events(self._viewmodel.events)

    async def _on_date(self, dates):
        self._pdate = _date_predicate(dates)
        await self._display_events(self._viewmodel.events)

    async def _display_events(self, events: list[OnThisDayEvent]):
        lst = self.ids.list
        lst.clear_widgets()
        event_pages = [
            (event, page)
            for event in events
            for page in event.pages
            if self._pkw(page) and self._pdate(page)
        ]
        for event, page in event_pages:
            on_this_day_page = OnThisDayPageWidget(
                thumbnail=page.thumbnail,
                text=_get_page_text(event, page),
            )
            lst.add_widget(on_this_day_page)


_PAGE_FMT = f"""[size=18][color={COLOR_YEAR}]{{}} [/color][color={COLOR_SEP}]|[/color] [color={COLOR_TITLE}]{{}}[/color][/size]
[color={COLOR_DESC}]{{}}[/color]"""


def _get_page_text(event: OnThisDayEvent, page: OnThisDayPage) -> str:
    return _PAGE_FMT.format(
        event.year,
        page.titles.get("normalized"),
        _shorten(page.description or page.extract),
    )


def _shorten(x: str):
    return x if len(x) < 100 else x[:100] + "..."
