# TimeMap Explorer - Design Document

## Introduction
The TimeMap Explorer app, implemented in Python using the [Kivy framework](https://kivy.org/), enables users to explore historical events on an interactive map. User can see events and historical borders on the map and the by adding dates and countries, the user can filter what can be seen. There is also a view for browsing events acquired from wikimedia OnThisDay API. 

Events can be filtered with as many keywords as desired and showing countries is only limited by the contents of the OpenHistoricalMap API. The user can also choose if they want to see event markers or borders on the map and all filter options can be saved. 

## User instructions
At starting the program you will see all the events and corresponding event markers that are aquired from the APIs. Youcan scroll the event list to see more events and change the shown area by dragging the map. If you are interested in seeing what event does the event marker pin show, you can click it. 

The shown events can be filtered according to date and keyword. Keywords can be added by typing them into the input box one by one or by separating with a comma. Using the return button will add the keywords. The keywords appear to the right of the input box and they are scrollable. Clicking a keyword deletes it. Keywords are searched from the event descriptions and events that contain any of the chosen keywords are shown. 

Filtering by date works similarly as keywords and while many dates can be included in filtering options, only one date can be added with one input. Use dd.mm.yyyy format to input the dates.

You can also view historical borders by searching a country. Not all countries are found in the border API and if a country is not found, a notification of that will appear in the input hint text. You can search countries with their English or native name. Countries' borders are shown on the map automatically but if you want to update the view, you can click the "Refresh!" button. 

Borders and event marker pins can be hidden by switching them off with the switches on the left.

All filter options can be cleared with the clear button and saved to your machine with the save button. If you want to use the previously saved filter, click the "Used saved filter" button.

## User Interface
### EventsView
The `EventsView` is responsible for displaying a list of historical events. These events are fetched based on the user's preferences, which are specified in the `FilterView`. 

The `EventsView` is a class that inherits from `BoxLayout` in Kivy, a Python library for developing multitouch applications. It's a flexible container for arranging children in vertical or horizontal orientation.

The `FilterView` is another class that provides an interface for the user to specify their preferences. These preferences can include the type of events, the date range, and other criteria.

When the user updates their preferences in the `FilterView`, it triggers a callback function in the `EventsView`. This function calls the `fetch_events` method of the `EventsModel` with the new filter.

The `EventsModel` then communicates with the `WikimediaAdapter` to fetch the new events. The `WikimediaAdapter` is responsible for interacting with the Wikimedia API and converting the response into a list of `Event` objects.

The `EventsModel` updates its `events` property with the new events. This property is a `PropagatedProperty` object, which means it's a special kind of property that automatically updates the `EventsView` when it changes.

The `EventsView` listens for changes in the `events` property of the `EventsModel` and updates its display whenever the `events` property changes. It does this by calling the `update_events` method, which clears the current events from the view and adds the new events.

Each event is displayed as an `EventWidget`, which is a class that inherits from `BoxLayout` and displays the details of an event. The `EventWidget` has an `id` property that allows it to be referred to from Python.

The `EventsView` has an `id` property that allows it to be referred to from Python. This ID can be used to access the `EventsView` from other parts of the program. For example, the `FilterView` can use this ID to trigger the callback function in the `EventsView` when the user updates their preferences.


### MapView
The MapView displays historical events on an interactive map with pins or borders, allowing users to explore events based on their geographical location.

### FilterView
The FilterView allows users to customize the displayed events in the EventsView and MapView by adjusting parameters, like date, country, and keyword.
Users can save and load filters according to their preferences, enabling the app to generate visualizations based on these parameters in subsequent visits.
The borders and event marker pins can also be hidden or shown by clicking their switches.
## Architecture
The structure of the TimeMap Explorer software can be organized using a modular and component-based architecture to ensure flexibility, scalability, and maintainability. 
### Model-View-ViewModel (MVVM)
This architectural pattern helps separate concerns within the application, making it easier to manage the data, user interface, and user interactions independently. For each major component, filter, events and map, we have a view module that is responsible for presenting the components to the user, view model that conveys the messages between the view and the model and does the necessary modifications for data and a model that stores the  data and takes care of business logic.

MVVM was chosen purely by instinct and while it was not the easiest one to implement, it seems to work quite well.
### Dependency Injection
A dependency injection framework or pattern can be used to manage the dependencies between components. This promotes modularity and facilitates unit testing.

## Key Components & Interfaces
```mermaid
classDiagram
    class MapView {
    }

    MapView --> MapViewModel: observes
    
    class MapViewModel {
        +eventMarkers: List~Marker~
        +borders: List~MapBorder~
        +showEventMarkers: bool
        +showBorders: bool
        +updateEventMarkers(List~Event~ events)
        +updateBorders(List~String~ countries)
        +hideBorders()
        +showBorders()
        +hideEventMarkers()
        +showEventMarkers()
    }

    MapViewModel --> BorderModel: observes

    class BorderModel {
        +borders: List~Border~
        +fetchBorders(List~String~ countries)
    }

    class OpenHistoricalMapAPI {
        + fetchBorder(String country) OpenHistoricalMapBorder
    }

    class OpenHistoricalMapAdapter {
        + fetchBorder(String country) Border
    }

    OpenHistoricalMapAdapter --> OpenHistoricalMapAPI
    OpenHistoricalMapAdapter --|> BorderAPI

    class BorderAPI {
        <<interface>>
        + fetchBorder(String country) Border
    }

    BorderModel --> OpenHistoricalMapAdapter

    class EventsView {
    }

    EventsView --> EventsViewModel: observes

    class EventsViewModel {
        +events: List~Event~
        +updateEvents(Filter filter)
    }

    EventsViewModel --> EventsModel: observes

    class EventsModel {
        +events: List~Event~ 
        +fetchEvents(Filter filter)
    }

    class WikimediaAPI {
        + fetchEvents(Filter filter) List~OnThisDayEvent~
    }

    class WikimediaAdapter {
        + fetchEvents(Filter filter) List~Event~
    }

    WikimediaAdapter --> WikimediaAPI
    WikimediaAdapter --|> EventsAPI

    class EventsAPI {
        <<interface>>
        + fetchEvents(Filter filter) List~Event~
    }

    EventsModel --> WikimediaAdapter

    class FilterView {
    }

    FilterView --> FilterViewModel: observes

    class FilterViewModel {
        +updateFilter(Filter filter)
    }

    FilterViewModel --> FilterModel: observes

    class FilterModel {
        +saveFilter(bool overwrite)
        +loadFilter(String id)
    }

    FilterModel --> Filter

    class Filter {
        +id: String?
        +showBorders: bool
        +showEventMarkers: bool
        +country: String?
        +keyword: String?
        +date: Date?
    }

    class AppView {
        +run()
    }

    AppView --> MapView
    AppView --> EventsView
    AppView --> FilterView


    EventsViewModel --> FilterModel: observes
    MapViewModel --> FilterModel: observes
    MapViewModel --> EventsModel: observes
```
Note: The diagram mainly illustrates the planned structure of our application and doesn't include all of the required properties and functions yet.

## Design Patterns
### Observer Pattern
The observer pattern can be implemented for components that need to react to changes in data or user interactions. For example, the user interface can observe changes in data and update the display accordingly. Kivy’s Properties implement this pattern for data binding.
### Adapter Pattern
The adapter pattern can be used to integrate with third-party APIs that have different interfaces. Adapter classes should be created that translate between the API and the internal application interface.

### Singleton Pattern
This was used as well

###Adapter pattern
Maybe used

## Other Design Principles
-  **Modular Design**

    Components and classes should be kept small and focused on specific responsibilities to promote modularity.
-  **SOLID Principles**
    We aimed to adhere to SOLID principles to keep the code clean and maintainable.	

## APIs
- [OpenHistoricalMap](https://nominatim.openhistoricalmap.org/search.html) provides historical borders of countries.
- [Wikimedia REST API(Feed/ onThisDay)](https://en.wikipedia.org/api/rest_v1/#/Feed/onThisDay) provides events with coordinates that historically happened on the provided day and month.

## Mid-Term Evaluation
The MVVM pattern makes it easier to manage the data, user interface, and user interactions independently. However, the correct way of implementing it was extremely difficult to grasp, especially in combination with the observer pattern. Since the pattern is quite complicated, the implementation of the components probably took longer than if we hadn't used it. 
The patterns are currently not consistenly implemented throughout the project yet which we will refactor in the future.

Moreover, we haven't implemented the adapter pattern for fetching events yet. The pattern will be adapted in future refactorings, which will include a simpler interface for events.

Furthermore, we had struggles with dependency injection of the `EventsModel` which is needed by two view models. Our configuration might have been faulty as two instances of the `EventsModel` were created even when we explicitly defining the class as a singleton. We will look into this issue but for now our conclusion is that dependency injection makes the application more complicated which might outweight its benefits for smaller projects. 

## AI Tool Usage
Chat GPT 3.5 was used to get the idea for the project. Project idea was received with the following prompt:
*Hi! We are a group of 4 people doing the Software Design Course at university. We got the task to design and implement a software / application, that fulfills the following requirements:
""" 1) The application must retrieve data from two separate third-party APIs (services). 2) ... 4) The design must be such that further data sources (e.g. another third-party API), or additional data from existing sources could be easily added. """
We want to create educational software. Please suggest 3 ideas and provide as many details as you can!*

As a result we received this suggestion:
*Historical Geography Time Machine:
Idea: Create an application that combines historical maps and geographical data from different time periods to offer users a time-traveling experience through geography.

Features:
- Data Sources: Utilize APIs or datasets with historical maps and geographical data.
Visualization: Enable users to explore maps and data from different eras, watching the evolution of borders, cities, and landscapes.
- User Interaction: Allow users to overlay historical maps onto modern ones, zoom in and out, and explore in 2D or 3D.
Customization: Users can set a specific time frame, location, and toggle various map layers.
Educational Content: Provide educational context about historical events, geography, and changes over time.
- Preference Saving: Users can save their preferred time and location settings for future exploration.
Expandability: Design the software to easily add more historical maps and data.

Use Cases: This application can be a valuable tool for history enthusiasts, students studying geography and history, and educators.*

Based on this suggestion we asked further ideas for the project:
*“Do you have ideas for a stand-alone app which includes historical events and a map?
It should have the following functional requirements. (project's requirements)”*


*Given the functional requirements you've outlined, here's a concept for a historical events and map app that meets these criteria:
App Name: TimeMap Explorer
Description:
TimeMap Explorer is an innovative and interactive historical events and map app that retrieves data from two separate third-party APIs and combines this data in a meaningful and visually appealing way. It allows users to explore historical events, customize their visualizations, save preferences, and easily accommodate additional data sources.

Key Features:
- Data Retrieval from Third-Party APIs:
The app integrates with two distinct third-party APIs, each providing valuable historical data. One API could provide historical events data, while the other could offer geographical or mapping data.
- Meaningful Data Visualization:
The app presents historical events on an interactive map, with events marked as pins or icons at their respective locations.
Users can adjust parameters like date, time, location, and data type to customize their visualizations.
The app employs advanced visualization techniques such as animated timelines, heatmaps, and clustering to provide insightful views of historical events.
- Customization and Data Selection:
Users can choose the types of data they want to see on the map. For example, they can display events related to wars, inventions, or cultural milestones simultaneously.
The app offers a selection menu where users can toggle the display of various data layers.
- Preference Saving and Retrieval:
Users can save their visualization preferences, such as a specific date range, historical categories, and map view settings.
Upon subsequent visits, users can fetch their saved preferences, and the app will generate visualizations with the most recent data based on these parameters.
- Modular Design for Scalability:
The app is designed to accommodate additional data sources or types easily. New third-party APIs can be integrated without major code changes.
A modular architecture ensures that the app can expand its offerings by adding more data categories or visualizations.
- User-Friendly Interface:
The user interface is intuitive, with easy-to-use controls for adjusting parameters and customizing visualizations.
The app employs user-friendly tooltips and tutorials to guide users in making the most of its features.
- Data Sources Attribution:
The app displays proper attribution for data sources, acknowledging the third-party APIs used for historical events and mapping.
- Community Collaboration:
Users can contribute historical events or suggest data sources, fostering a sense of community engagement and knowledge sharing.
- Offline Access:
The app supports limited offline access, allowing users to view previously accessed data even without an internet connection.

By following these functional requirements, TimeMap Explorer aims to provide a unique and engaging way for users to explore historical events through interactive maps while offering the flexibility to adapt to future data sources and visualization needs.*


Furthermore, some pattern ideas were received from ChatGPT 3.5. Later on ChatGPT 4.0 was used to explore the implementation approaches.

During the development process Copilot was used to speed up coding. No "separate" prompts were used for copilot but the suggestions were often used.
