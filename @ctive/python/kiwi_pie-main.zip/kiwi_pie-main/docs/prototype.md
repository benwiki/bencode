# Kiwi Pie group’s Prototype specifications

## Figma
We designed a layout in Figma that represents the basic functionality of our project.
The extracted PDF file can be found in the `src\prototype_docs` folder.
The original Figma link is (here)[https://www.figma.com/file/jy9LvpRmlottgnqy6SfUEL/Software-design-prototype?type=design&node-id=0%3A1&mode=design&t=L68cDJPznJjLw2Jv-1].

## Code
On top of that, we created the first basic outlook of the program in real code too.
See `src\kiwi_pie` for the source code.

Pictures about the code in action:
