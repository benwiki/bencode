# Kiwi Pie: Software Design Project - TimeMap Explorer

The prototype specifications and the design document can be found in (`/prototype_docs`)[https://course-gitlab.tuni.fi/comp.se.110-software-design_2023-2024/kiwi_pie/-/tree/main/prototype_docs] in MARKDOWN (.md) format.

<!-- Reference for GLFM syntax: https://docs.gitlab.com/ee/user/markdown.html -->

## Notes for developers

<details>
<summary>Poetry</summary>

Poetry is a Python package manager. Install instructions [here](https://python-poetry.org/docs/#installing-with-the-official-installer). You can also just try running the following:

```shell
curl -sSL https://install.python-poetry.org | python3 -
```

or, if you have `pipx` installed:

```shell
pipx install poetry
```

In VS Code, to use the environment during debugging:
1. Do `poetry env info`, copy virtualenv executable path
2. In VS Code, do F1 > `Python: Select Interpreter` > `Enter interpreter path...`

Some commands:
- install dependencies: `poetry install`
- adding dependency: `poetry add <dep-name>`
- adding a dev dependency: `poetry add --group dev <dep-name>`
- entering virtual environment: `poetry shell`
- running single command in venv: `poetry run <cmd>`

</details>

<details>
<summary>Running the project</summary>

Run the program as a module so that imports work the same in development and deployment: `python3 -m kiwi_pie`

Make sure the dependencies are installed and exposed to the current running environment, e.g. by entering `poetry shell`, or by `poetry run python3 -m kiwi_pie`.

An example `launch.json` (for VS Code):
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: Module",
            "type": "python",
            "request": "launch",
            "module": "kiwi_pie",
            "justMyCode": true
        }
    ]
}
```
</details>

<details>
<summary>Git</summary>

This project uses git for version control. A flow of using git is:  
1. `git checkout main && git pull` get changes
1. `git checkout -b <branch>` start work on branch
1. `git commit -am "<message>"` commit work (on version-controlled files)
1. `git push -u origin HEAD` push work to remote for pull request (GitLab lingo: merge request)

If `main` has been updated, you need to merge the changes to your branch:
1. [`git stash` stash uncommitted changes]
1. `git checkout main && git pull` get changes
1. `git checkout <branch>` switch to your branch
1. `git rebase main` merge changes from main to your branch
1. [If there are conflicts, one can use VS Code Ctrl+Shift+G view for easy resolution]
1. [`git stash pop` apply stashed changes]
1. `git push --force-with-lease` force push to remote

</details>

<details>

<summary>CI/CD</summary>

As university doesn't offer runners, one needs to register one's own runner. Docker reference [here](https://docs.gitlab.com/runner/install/docker.html). In short, it should suffice to run:

```shell
docker-compose up -d  # might also be docker compose up -d
```

Copy the token from GitLab's `CI/CD Settings` > `New runner`, and replace `<TOKEN>` in below command with the retrieved token:

```shell
docker exec -it `docker-compose ps -q` gitlab-runner register --url https://course-gitlab.tuni.fi --token <TOKEN>
```

The CI/CD will build the project and run tests defined in `test/` subdirectory.

</details>
